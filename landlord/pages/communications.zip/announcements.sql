-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2025 at 07:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bt_jengopay`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `priority` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Sent','Draft','Archived') DEFAULT 'Sent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `recipient`, `priority`, `message`, `created_at`, `updated_at`, `status`) VALUES
(79, 'UUU', 'Urgent', 'hjhjhj', '2025-06-30 00:00:00', '2025-06-30 15:02:39', 'Sent'),
(80, 'huh', 'Normal', 'nkj', '2025-06-30 00:00:00', '2025-06-30 15:02:39', 'Sent'),
(82, 'huh', 'Urgent', 'nhh', '2025-06-30 00:00:00', '2025-06-30 15:02:39', 'Sent'),
(84, 'huh', 'Urgent', 'utj7yt', '2025-06-30 00:00:00', '2025-06-30 15:02:39', 'Sent'),
(85, 'Uzima Towers', 'Urgent', 'gyjvuyjv', '2025-06-30 13:41:24', '2025-06-30 15:02:39', 'Sent'),
(86, 'Uzima Towers', 'Normal', 'sdfggg', '2025-06-30 13:49:21', '2025-06-30 15:02:39', 'Sent'),
(87, 'UUU', 'Urgent', 'gjhjj', '2025-06-30 13:50:08', '2025-06-30 15:02:39', 'Sent'),
(88, 'WAQEW', 'Urgent', 'ghghy', '2025-06-30 13:54:42', '2025-06-30 15:02:39', 'Sent'),
(89, 'huh', 'Urgent', 'gfhyyuj', '2025-06-30 13:58:42', '2025-06-30 15:02:39', 'Sent'),
(90, 'WAQEW', 'Normal', 'cxvfg', '2025-06-30 14:03:37', '2025-06-30 15:03:37', 'Sent'),
(91, 'WAQEW', 'Urgent', 'mnuju', '2025-06-30 14:17:31', '2025-06-30 14:17:31', 'Sent'),
(92, 'WATER ', 'Reminder', 'nbbhvjhg', NULL, NULL, 'Sent'),
(93, 'UUU', 'Urgent', 'bbbb', NULL, NULL, 'Sent'),
(94, 'WATER ', 'Reminder', 'ccfgb', '2025-06-30 14:22:48', '2025-06-30 14:22:48', 'Sent'),
(95, 'Uzima Towers', 'Reminder', 'gghgh', '2025-06-30 14:26:03', '2025-06-30 14:26:03', 'Sent'),
(96, 'WAQEW', 'Reminder', 'rthh', '2025-06-30 14:29:19', '2025-06-30 14:29:19', 'Sent'),
(97, 'UUU', 'Normal', 'wedf', '2025-06-30 14:29:39', '2025-06-30 14:29:39', 'Sent'),
(98, 'huh', 'Urgent', 'jnuijn', '2025-06-30 14:30:10', '2025-06-30 14:30:10', 'Sent'),
(100, 'Ben 10', 'Normal', 'dcv', '2025-06-30 14:34:18', '2025-06-30 14:34:18', 'Sent'),
(101, 'Alpha', 'Normal', 'bghfgh', '2025-06-30 14:36:21', '2025-06-30 14:36:21', 'Sent'),
(102, 'Alpha', 'Normal', 'ghjhj', '2025-06-30 16:32:48', '2025-06-30 16:32:48', 'Sent'),
(103, 'huh', 'Urgent', 'ytjuyu', '2025-06-30 16:34:00', '2025-06-30 16:34:00', 'Sent'),
(104, 'Uzima Towers', 'Reminder', 'jhjj', '2025-06-30 16:34:43', '2025-06-30 16:34:43', 'Sent'),
(105, 'Uzima Towers', 'Normal', 'edcf', '2025-06-30 16:35:01', '2025-06-30 16:35:01', 'Sent'),
(106, 'Uzima Towers', 'Urgent', 'tyhg', '2025-06-30 16:36:20', '2025-06-30 16:36:20', 'Sent'),
(107, 'UUU', 'Urgent', 'jmhjkj', '2025-06-30 16:36:51', '2025-06-30 16:36:51', 'Sent'),
(108, 'WAQEW', 'Urgent', 'dgdhh', '2025-06-30 16:37:38', '2025-06-30 16:37:38', 'Sent'),
(110, '', 'Urgent', 'cxbfgggg', '2025-06-30 16:39:31', '2025-06-30 17:39:31', 'Draft'),
(111, 'WAQEW', 'Normal', 'cxbfgggg', '2025-07-02 09:07:06', '2025-07-02 09:07:06', 'Sent'),
(112, 'WAQEW', 'Normal', 'hgnj', '2025-07-02 09:10:59', '2025-07-02 09:10:59', 'Sent'),
(113, 'fefv', 'Normal', 'ghyhyhy', '2025-07-02 09:24:16', '2025-07-02 09:24:16', 'Sent'),
(114, 'huh', 'Urgent', 'gttty', '2025-07-02 09:26:56', '2025-07-02 09:26:56', 'Sent'),
(115, 'WATER ', 'Reminder', 'dfgfdgfd', '2025-07-02 09:27:12', '2025-07-02 09:27:12', 'Sent'),
(116, 'WAQEW', 'Normal', 'htyh', '2025-07-02 09:32:53', '2025-07-02 09:32:53', 'Sent'),
(117, 'WATER ', 'Normal', 'ghfjj', '2025-07-02 09:33:13', '2025-07-02 09:33:13', 'Sent'),
(118, '', 'Urgent', 'kjk', '2025-07-02 09:39:44', '2025-07-02 10:39:44', 'Draft'),
(119, '', 'Urgent', 'kjk', '2025-07-02 09:39:45', '2025-07-02 10:39:45', 'Draft'),
(120, '', 'Urgent', 'kjk', '2025-07-02 09:40:40', '2025-07-02 10:40:40', 'Draft'),
(121, 'WAQEW', 'Urgent', 'kjk', '2025-07-02 09:40:42', '2025-07-02 09:40:42', 'Sent'),
(122, '', 'Urgent', 'ghthth', '2025-07-02 09:40:52', '2025-07-02 10:40:52', 'Draft'),
(123, '', 'Urgent', 'ghthth', '2025-07-02 09:40:52', '2025-07-02 10:40:52', 'Draft'),
(124, '', 'Urgent', 'ghthth', '2025-07-02 09:40:53', '2025-07-02 10:40:53', 'Draft'),
(125, '', 'Urgent', 'ghthth', '2025-07-02 09:40:53', '2025-07-02 10:40:53', 'Draft'),
(126, '', 'Urgent', 'ghthth', '2025-07-02 09:40:55', '2025-07-02 10:40:55', 'Draft'),
(127, '', 'Urgent', 'ghthth', '2025-07-02 09:40:55', '2025-07-02 10:40:55', 'Draft'),
(128, '', 'Urgent', 'ghthth', '2025-07-02 09:40:55', '2025-07-02 10:40:55', 'Draft'),
(129, '', 'Urgent', 'ghthth', '2025-07-02 09:40:55', '2025-07-02 10:40:55', 'Draft'),
(130, '', 'Urgent', 'ghthth', '2025-07-02 09:40:55', '2025-07-02 10:40:55', 'Draft'),
(131, '', 'Urgent', 'ghthth', '2025-07-02 09:40:56', '2025-07-02 10:40:56', 'Draft'),
(132, '', 'Urgent', 'ghthth', '2025-07-02 09:40:57', '2025-07-02 10:40:57', 'Draft'),
(133, '', 'Urgent', 'ghthth', '2025-07-02 09:40:57', '2025-07-02 10:40:57', 'Draft'),
(134, '', 'Urgent', 'ghthth', '2025-07-02 09:40:57', '2025-07-02 10:40:57', 'Draft'),
(135, '', 'Urgent', 'ghthth', '2025-07-02 09:41:15', '2025-07-02 10:41:15', 'Draft'),
(136, '', 'Urgent', 'ghthth', '2025-07-02 09:41:16', '2025-07-02 10:41:16', 'Draft'),
(137, '', 'Urgent', 'ghthth', '2025-07-02 09:41:16', '2025-07-02 10:41:16', 'Draft'),
(138, '', 'Urgent', 'ghthth', '2025-07-02 09:41:28', '2025-07-02 10:41:28', 'Draft'),
(139, '', 'Reminder', 'ghthth', '2025-07-02 09:41:45', '2025-07-02 10:41:45', 'Draft'),
(140, '', 'Reminder', 'ghthth', '2025-07-02 09:50:29', '2025-07-02 10:50:29', 'Draft'),
(141, '', 'Reminder', 'ghthth', '2025-07-02 09:50:29', '2025-07-02 10:50:29', 'Draft'),
(142, 'WATER ', 'Reminder', 'ghthth', '2025-07-02 09:50:40', '2025-07-02 09:50:40', 'Sent'),
(143, 'Uzima Towers', 'Urgent', 'ujihuh', '2025-07-02 09:51:44', '2025-07-02 09:51:44', 'Sent'),
(144, '', 'Urgent', 'ujihuh', '2025-07-02 09:51:47', '2025-07-02 10:51:47', 'Draft'),
(145, 'WAQEW', 'Urgent', 'gy7gyuy', '2025-07-02 10:03:39', '2025-07-02 10:03:39', 'Sent'),
(146, '', 'Normal', 'uhiuiu', '2025-07-02 10:03:52', '2025-07-02 11:03:52', 'Draft'),
(147, '', 'Normal', 'uhiuiu', '2025-07-02 10:08:52', '2025-07-02 11:08:52', 'Draft'),
(148, 'huh', 'Urgent', 'cdffr', '2025-07-02 10:11:14', '2025-07-02 10:11:14', 'Sent'),
(149, '', 'Normal', 'bgbbh', '2025-07-02 10:12:38', '2025-07-02 11:12:38', 'Draft'),
(150, '', 'Normal', 'bgbbh', '2025-07-02 10:12:38', '2025-07-02 11:12:38', 'Draft'),
(151, '', 'Normal', 'bgbbh', '2025-07-02 10:15:20', '2025-07-02 11:15:20', 'Draft'),
(152, '', 'Normal', 'bgbbh', '2025-07-02 10:15:20', '2025-07-02 11:15:20', 'Draft'),
(153, '', 'Normal', 'bgbbh', '2025-07-02 10:15:54', '2025-07-02 11:15:54', 'Draft'),
(154, '', 'Normal', 'bgbbh', '2025-07-02 10:15:54', '2025-07-02 11:15:54', 'Draft'),
(155, '', 'Normal', 'bgbbh', '2025-07-02 10:17:01', '2025-07-02 11:17:01', 'Draft'),
(156, '', 'Normal', 'bgbbh', '2025-07-02 10:17:02', '2025-07-02 11:17:02', 'Draft'),
(157, 'UUU', 'Normal', 'bgbbh', '2025-07-02 10:17:07', '2025-07-02 10:17:07', 'Sent'),
(158, 'UUU', 'Normal', 'bguygy', '2025-07-02 10:17:41', '2025-07-02 10:17:41', 'Sent'),
(159, '', 'Normal', 'jjkjk', '2025-07-02 10:19:08', '2025-07-02 11:19:08', 'Draft'),
(160, '', 'Normal', 'jjkjk', '2025-07-02 10:19:11', '2025-07-02 11:19:11', 'Draft'),
(161, 'huh', 'Normal', 'jjkjk', '2025-07-02 10:19:12', '2025-07-02 10:19:12', 'Sent'),
(162, 'UUU', 'Reminder', 'ffbghbg', '2025-07-02 10:23:23', '2025-07-02 10:23:23', 'Sent'),
(163, 'huh', 'Normal', 'fdggtt', '2025-07-02 10:23:35', '2025-07-02 10:23:35', 'Sent'),
(164, 'UUU', 'Normal', 'gghgh', '2025-07-02 10:23:51', '2025-07-02 10:23:51', 'Sent'),
(165, 'Uzima Towers', 'Normal', 'huuhygby', '2025-07-02 10:35:04', '2025-07-02 10:35:04', 'Sent'),
(166, 'huh', 'Normal', 'hhguy', '2025-07-02 10:52:54', '2025-07-02 10:52:54', 'Sent'),
(167, '', 'Urgent', 'hhyyhyh', '2025-07-02 10:54:36', '2025-07-02 11:54:36', 'Draft'),
(168, '', 'Urgent', 'hhyyhyh', '2025-07-02 10:54:37', '2025-07-02 11:54:37', 'Draft'),
(169, 'Uzima Towers', 'Urgent', 'hhyyhyh', '2025-07-02 10:54:38', '2025-07-02 10:54:38', 'Sent'),
(170, 'Uzima Towers', 'Urgent', 'ggttt', '2025-07-02 10:56:55', '2025-07-02 10:56:55', 'Sent'),
(171, 'Uzima Towers', 'Normal', 'ghjhjg', '2025-07-02 11:04:56', '2025-07-02 11:04:56', 'Sent'),
(172, 'Uzima Towers', 'Normal', 'hjkjhk', '2025-07-02 11:21:47', '2025-07-02 11:21:47', 'Sent'),
(173, 'Uzima Towers', 'Normal', 'ghhnjhg', '2025-07-02 11:24:31', '2025-07-02 11:24:31', 'Sent'),
(174, 'Uzima Towers', 'Urgent', 'mij', '2025-07-02 11:34:58', '2025-07-02 11:34:58', 'Sent'),
(175, '', 'Reminder', 'joiooij', '2025-07-02 11:35:16', '2025-07-02 12:35:16', 'Draft'),
(176, '', 'Reminder', 'joiooij', '2025-07-02 11:35:17', '2025-07-02 12:35:17', 'Draft'),
(177, '', 'Reminder', 'joiooij', '2025-07-02 11:35:17', '2025-07-02 12:35:17', 'Draft'),
(178, 'huh', 'Reminder', 'joiooij', '2025-07-02 11:35:32', '2025-07-02 11:35:32', 'Sent'),
(179, 'Uzima Towers', 'Normal', 'jijiojioj', '2025-07-02 11:37:06', '2025-07-02 11:37:06', 'Sent'),
(180, 'Uzima Towers', 'Normal', 'njnjnj', '2025-07-02 11:39:19', '2025-07-02 11:39:19', 'Sent'),
(181, 'Uzima Towers', 'Reminder', 'cbvn', '2025-07-02 11:40:57', '2025-07-02 11:40:57', 'Sent'),
(182, '', 'Urgent', 'jgh', '2025-07-02 11:46:41', '2025-07-02 12:46:41', 'Draft'),
(183, 'WAQEW', 'Urgent', 'jgh', '2025-07-02 11:46:44', '2025-07-02 11:46:44', 'Sent'),
(184, 'UUU', 'Normal', 'bhmbjhmk', '2025-07-02 11:48:07', '2025-07-02 11:48:07', 'Sent'),
(185, 'UUU', 'Reminder', 'niklnkjnnj', '2025-07-02 11:50:45', '2025-07-02 11:50:45', 'Sent'),
(186, 'WAQEW', 'Normal', 'ghfgjhgh', '2025-07-02 11:51:04', '2025-07-02 11:51:04', 'Sent'),
(187, 'WAQEW', 'Reminder', 'njnijjji', '2025-07-02 11:53:09', '2025-07-02 11:53:09', 'Sent'),
(188, 'WATER ', 'Reminder', 'drtycty', '2025-07-02 11:56:44', '2025-07-02 11:56:44', 'Sent'),
(189, 'WAQEW', 'Normal', 'hghjhgj', '2025-07-02 11:59:24', '2025-07-02 11:59:24', 'Sent'),
(190, 'WATER ', 'Normal', 'ghgfhf', '2025-07-02 12:01:21', '2025-07-02 12:01:21', 'Sent'),
(191, 'yujjk', 'Normal', 'ghgh', '2025-07-02 12:34:17', '2025-07-02 12:34:17', 'Sent'),
(192, 'Uzima Towers', 'Normal', 'fythuf', '2025-07-02 13:13:41', '2025-07-02 13:13:41', 'Sent'),
(193, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:50', '2025-07-02 14:13:50', 'Draft'),
(194, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:51', '2025-07-02 14:13:51', 'Draft'),
(195, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:51', '2025-07-02 14:13:51', 'Draft'),
(196, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:51', '2025-07-02 14:13:51', 'Draft'),
(197, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:51', '2025-07-02 14:13:51', 'Draft'),
(198, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:51', '2025-07-02 14:13:51', 'Draft'),
(199, '', 'Normal', 'tgdytdy', '2025-07-02 13:13:52', '2025-07-02 14:13:52', 'Draft'),
(200, 'UUU', 'Normal', 'tgdytdy', '2025-07-02 13:19:05', '2025-07-02 13:19:05', 'Sent'),
(201, 'WAQEW', 'Urgent', 'dhfghb', '2025-07-02 13:20:41', '2025-07-02 13:20:41', 'Sent'),
(202, '', 'Normal', 'scdfdggd', '2025-07-02 13:33:26', '2025-07-02 14:33:26', 'Draft'),
(204, '', 'Normal', 'scdfdggd', '2025-07-02 13:33:27', '2025-07-02 14:33:27', 'Draft'),
(205, 'huh', 'Normal', 'fghh', '2025-07-02 13:36:30', '2025-07-02 13:36:30', 'Sent'),
(206, 'UUU', 'Urgent', 'fcbcvh', '2025-07-02 13:37:10', '2025-07-02 13:37:10', 'Sent'),
(207, 'Uzima Towers', 'Urgent', 'uhjiuhui', '2025-07-02 13:47:19', '2025-07-02 13:47:19', 'Sent'),
(208, 'Uzima Towers', 'Urgent', 'UIHIHHHHHHH', '2025-07-02 13:52:01', '2025-07-02 13:52:01', 'Sent'),
(209, 'Uzima Towers', 'Normal', 'KJHIHU', '2025-07-02 13:52:36', '2025-07-02 13:52:36', 'Sent'),
(212, 'WATER ', 'Reminder', 'FGFGDGFD', '2025-07-02 14:02:30', '2025-07-02 15:32:23', 'Archived'),
(224, 'UUU', 'Urgent', 'kmiji', '2025-07-02 14:56:36', '2025-07-02 14:56:36', 'Sent'),
(225, 'WAQEW', 'Normal', 'jkhih', '2025-07-02 14:57:20', '2025-07-02 14:57:20', 'Sent'),
(226, 'Amazing Towers', 'Urgent', 'fhjbkn', '2025-07-02 16:22:31', '2025-07-02 16:22:31', 'Sent'),
(227, 'Amazing Towers', 'Reminder', 'Greetings,\r\nRemember to remove the litter bags.\r\nKind Regards.', '2025-07-02 17:34:09', '2025-07-02 18:39:30', 'Sent'),
(228, 'Amazing Towers', 'Urgent', 'Greetings,\nVacate immediately!\nKind regards.', '2025-07-02 17:40:45', '2025-07-02 18:40:45', 'Draft'),
(229, 'Amazing Towers', 'Urgent', 'Greetings,\nVacate immediately!\nKind regards.', '2025-07-02 17:40:46', '2025-07-02 18:40:46', 'Draft'),
(230, 'Amazing Towers', 'Urgent', 'Greetings,\nVacate immediately!\nKind regards.', '2025-07-02 17:40:46', '2025-07-02 18:40:46', 'Draft'),
(231, 'Amazing Towers', 'Urgent', 'Greetings,\nVacate immediately!\nKind regards.', '2025-07-02 17:40:46', '2025-07-02 18:40:46', 'Draft'),
(232, 'Amazing Towers', 'Urgent', 'Greetings,\nVacate immediately!\nKind regards.', '2025-07-02 17:40:46', '2025-07-02 18:40:46', 'Draft'),
(233, 'Amazing Towers', 'Urgent', 'Greetings,\nVacate immediately!\nKind regards.', '2025-07-02 17:40:47', '2025-07-02 18:40:47', 'Draft'),
(234, 'Amazing Towers', 'Urgent', 'Greetings,\r\nVacate immediately!\r\nWelcome.\r\nKind regards.', '2025-07-02 17:40:50', '2025-07-02 18:41:42', 'Draft');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
