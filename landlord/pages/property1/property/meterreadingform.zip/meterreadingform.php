<!-- meterreading popup -->
<div class="meterpopup-overlay" id="meterPopup">
    <div class="meterpopup-content wide-form">
        <button id="close-btns" class="text-secondary" onclick="meterreadingclosePopup()">×</button>
        <h2 class="assign-title">Add A Meter Reading</h2>
        <form class="wide-form" id="meterForm" method="POST" action="">

 <!-- ✅ Hidden field for JS to access building ID -->
      <input type="hidden" id="building_id" value="<?php echo htmlspecialchars($buildingId); ?>">
        
            <div class="form-group">
                <b><label for="dateInput" class="filter-label">Reading Date</label></b>
                <input type="date" id="dateInput" name="reading_date" class="form-control" required />
            </div>
            <div class="form-group">
                <select id="units" name="unit_number" required onchange="checkPreviousReading()">
                    <option value="">-- Select Unit --</option>
                    <?php foreach ($units as $unit): ?>
                        <option value="<?php echo htmlspecialchars($unit['unit_number']); ?>">
                            <?php echo htmlspecialchars($unit['unit_number']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="meter_type">Meter Type:</label>
                <select id="meter_type" name="meter_type" required>
                    <option value="">-- Select Meter Type --</option>
                    <option value="Water">Water</option>
                    <option value="Electrical">Electrical</option>
                </select>
            </div>

            <div class="form-group">
                <label for="previous_reading">Previous Reading:</label>
                <input type="number" id="previous_reading" name="previous_reading" placeholder="Previous Reading" required>
                <small id="prev_reading_note" style="color: gray; display: none;">
                    This is the first reading for this unit.
                </small>
            </div>

            <div class="form-group">
                <label for="current_reading">Current Reading:</label>
                <input type="number" id="current_reading" name="current_reading" placeholder="Current Reading" required>
            </div>

            <div class="form-group">
                <label>Consumption Units:</label>
                <p id="consumption_preview"><i>Calculated automatically</i></p>
            </div>


            <div class="form-group">
                <label>Consumption Cost:</label>
                <p id="consumption_cost"><i>Calculated automatically</i></p>
                <input type="hidden" id="consumption_cost_value" name="consumption_cost">
            </div>

            <button type="submit" name="submit" class="submit-btn">Create Meter Reading</button>
        </form>
    </div>
</div>

<!-- js -->

<script>
  // Function to meter the meter popup
  function meterreadingopenPopup() {
    document.getElementById("meterPopup").style.display = "flex";
  }

  // Function to close the meter popup
  function meterreadingclosePopup() {
    document.getElementById("meterPopup").style.display = "none";
  }
</script>